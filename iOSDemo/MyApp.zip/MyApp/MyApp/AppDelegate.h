//
//  AppDelegate.h
//  MyApp
//
//  Created by hcl on 2022/9/7.
//

#import <UIKit/UIKit.h>
#import <Flutter/Flutter.h>

@interface AppDelegate : FlutterAppDelegate // More on the FlutterAppDelegate below.

@property (nonatomic,strong) FlutterEngine *flutterEngine;

@end

