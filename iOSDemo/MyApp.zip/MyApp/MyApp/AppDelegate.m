//
//  AppDelegate.m
//  MyApp
//
//  Created by hcl on 2022/9/7.
//

#import "AppDelegate.h"
#import <FlutterPluginRegistrant/GeneratedPluginRegistrant.h>
#import "FlutterController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

- (void)dismissWindow:(UIWindow *)window {
    [window resignKeyWindow];
    window = nil;
}

- (BOOL)application:(UIApplication *)application
    didFinishLaunchingWithOptions:(NSDictionary<UIApplicationLaunchOptionsKey, id> *)launchOptions {
  self.flutterEngine = [[FlutterEngine alloc] initWithName:@"my flutter engine"];
  // Runs the default Dart entrypoint with a default Flutter route.
  [self.flutterEngine run];
  // Used to connect plugins (only if you have plugins with iOS platform code).
  [GeneratedPluginRegistrant registerWithRegistry:self.flutterEngine];
    
    FlutterController *vc = [[FlutterController alloc] initWithEngine:self.flutterEngine nibName:nil bundle:nil];
    UIWindow *window = [[UIWindow alloc] initWithFrame:CGRectZero];
    window.windowLevel = UIWindowLevelNormal - 1;
    [window setRootViewController:vc];
    [window makeKeyAndVisible];
    [self performSelector:@selector(dismissWindow:) withObject:window afterDelay:1.0];
    
  return [super application:application didFinishLaunchingWithOptions:launchOptions];
}

@end
